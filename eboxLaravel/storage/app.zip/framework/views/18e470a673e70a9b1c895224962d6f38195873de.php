
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('auth.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<div class="row">
			<h1>PORTAL</h1>
	</div>
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('errors')); ?>

    </div>
<?php endif; ?> 
    <form action="<?php echo e(url('/portals')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php $__currentLoopData = $portal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- <input type="hidden" value="<?php echo e($port->id); ?>"/> -->
	<div class="row input-container">
			<div class="col-xs-12">
				<div class="form-group port-desing">
                <label>Portal 1</label> 
					<input type="text" name="portal_one" value="<?php echo e($port->portal_one); ?>" class="form-control"/>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>Portal 2</label>
					<input type="text" name="portal_two"  value="<?php echo e($port->portal_two); ?>" class="form-control"/> 
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>Portal 3</label>
					<input type="text" name="portal_three" value="<?php echo e($port->portal_three); ?>" class="form-control"/> 
				</div>
			</div>
            <div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>Portal 4</label> 
					<input type="text" name="portal_four"  value="<?php echo e($port->portal_four); ?>" class="form-control"/>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
					<label>Portal 5</label> 
					<input type="text" name="portal_five"  value="<?php echo e($port->portal_five); ?>" class="form-control"/> 
				</div>
			</div>
            <div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>Portal 6</label> 
					<input type="text" name="portal_six"  value="<?php echo e($port->portal_six); ?>" class="form-control"/>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
					<label>Portal 7</label> 
					<input type="text" name="portal_seven"  value="<?php echo e($port->portal_seven); ?>" class="form-control"/> 
				</div>
			</div>
			<div class="col-xs-12">
				<div class="form-group port-desing">
                <label>Portal 8</label>
				<input type="text" name="portal_eight" value="<?php echo e($port->portal_eight); ?>" class="form-control"/>
				</div>
			</div>
			<div class="col-xs-12">
				<input type="submit" class="btn btn-primary btn-lg" value="Submit The Data"/>
			</div>
	</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
</div>
<style>
    body {
    background-color: #444442;
    /* padding-top: 85px; */
}
.form-group.port-desing input {
    background: #2D2D2D;
    height: 50px;
    border: 1px solid #2D2D2D;
    margin-bottom: 30px;
    color: #fff;
}
.form-group.port-desing label {
    color: #fff;
    font-size: 18px;
    margin-bottom: 10px;
    font-weight: 600;
}
h1 {
    font-family: 'Poppins', sans-serif, 'arial';
    font-weight: 600;
    font-size: 50px;
    color: white;
    padding-top:50px;
    text-align: center;
}

h4 {
    font-family: 'Roboto', sans-serif, 'arial';
    font-weight: 400;
    font-size: 20px;
    color: #9b9b9b;
    line-height: 1.5;
}

/* ///// inputs /////*/

input:focus ~ label, textarea:focus ~ label, input:valid ~ label, textarea:valid ~ label {
    font-size: 0.75em;
    color: #999;
    top: -5px;
    -webkit-transition: all 0.225s ease;
    transition: all 0.225s ease;
}

.styled-input {
    float: left;
    width: 293px;
    margin: 1rem 0;
    position: relative;
    border-radius: 4px;
}

@media  only screen and (max-width: 768px){
    .styled-input {
        width:100%;
    }
}

.styled-input label {
    color: #999;
    padding: 1.3rem 30px 1rem 30px;
    position: absolute;
    top: 10px;
    left: 0;
    -webkit-transition: all 0.25s ease;
    transition: all 0.25s ease;
    pointer-events: none;
}

.styled-input.wide { 
    width: 650px;
    max-width: 100%;
}

input,
textarea {
    padding: 30px;
    border: 0;
    width: 100%;
    font-size: 1rem;
    background-color: #2d2d2d;
    color: white;
    border-radius: 4px;
}

input:focus,
textarea:focus { outline: 0; }

input:focus ~ span,
textarea:focus ~ span {
    width: 100%;
    -webkit-transition: all 0.075s ease;
    transition: all 0.075s ease;
}

textarea {
    width: 100%;
    min-height: 15em;
}

.input-container {
    width: 650px;
    max-width: 100%;
    margin: 20px auto 25px auto;
}

.submit-btn {
    float: right;
    padding: 7px 35px;
    border-radius: 60px;
    display: inline-block;
    background-color: #4b8cfb;
    color: white;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.06),
              0 2px 10px 0 rgba(0,0,0,0.07);
    -webkit-transition: all 300ms ease;
    transition: all 300ms ease;
}

.submit-btn:hover {
    transform: translateY(1px);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,0.10),
              0 1px 1px 0 rgba(0,0,0,0.09);
}

@media (max-width: 768px) {
    .submit-btn {
        width:100%;
        float: none;
        text-align:center;
    }
}

input[type=checkbox] + label {
  color: #ccc;
  font-style: italic;
} 

input[type=checkbox]:checked + label {
  color: #f00;
  font-style: normal;
}
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paneliplaytv/public_html/resources/views/portal.blade.php ENDPATH**/ ?>