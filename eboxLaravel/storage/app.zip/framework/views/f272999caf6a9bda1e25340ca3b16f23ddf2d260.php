
<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('errors')); ?>

    </div>
<?php endif; ?> 

	<div class="row">
    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Portals</h4>
                                <div class="basic-form">
                                <form action="<?php echo e(url('/portals')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php $__currentLoopData = $portal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal One</label>
                                                <input type="text" name="portal_one" value="<?php echo e($port->portal_one); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message One</label>
                                                <input type="text" name="portal_message_one" value="<?php echo e($port->portal_message_one); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Two</label>
                                                <input type="text" name="portal_two"  value="<?php echo e($port->portal_two); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Two</label>
                                                <input type="text" name="portal_message_two"  value="<?php echo e($port->portal_message_two); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Three</label>
                                                <input type="text" name="portal_three"  value="<?php echo e($port->portal_three); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Two</label>
                                                <input type="text" name="portal_message_three"  value="<?php echo e($port->portal_message_three); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>


                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Four</label>
                                                <input type="text" name="portal_four"  value="<?php echo e($port->portal_four); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Four</label>
                                                <input type="text" name="portal_message_four"  value="<?php echo e($port->portal_message_four); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Five</label>
                                                <input type="text" name="portal_five"  value="<?php echo e($port->portal_five); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Five</label>
                                                <input type="text" name="portal_message_five"  value="<?php echo e($port->portal_message_five); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>


                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Six</label>
                                                <input type="text" name="portal_six"  value="<?php echo e($port->portal_six); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Six</label>
                                                <input type="text" name="portal_message_six"  value="<?php echo e($port->portal_message_six); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Seven</label>
                                                <input type="text" name="portal_seven"  value="<?php echo e($port->portal_seven); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Seven</label>
                                                <input type="text" name="portal_message_seven"  value="<?php echo e($port->portal_message_seven); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Portal Eight</label>
                                                <input type="text" name="portal_eight"  value="<?php echo e($port->portal_eight); ?>" class="form-control" placeholder="Email">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Portal Message Six</label>
                                                <input type="text" name="portal_message_eight"  value="<?php echo e($port->portal_message_eight); ?>"  class="form-control" placeholder="Password">
                                            </div>
                                        </div>
                                        <div class="general-button">
                                    <button type="submit" class="btn mb-1 btn-flat btn-success">Update Version</button>
                                </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

	</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN\resources\views/portal.blade.php ENDPATH**/ ?>