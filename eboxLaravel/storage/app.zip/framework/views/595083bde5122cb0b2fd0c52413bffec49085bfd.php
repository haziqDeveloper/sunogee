

  <style>
    .page-item.active .page-link{
        z-index: 3;
        color: #ffffff !important ;
        border-radius: 0;
        padding: 6px 12px;
    }
    .pagination {
      justify-content: end;
    }
    #productsTable_paginate
    {
     display:none;   
    }
    .page-link{
        z-index: 3;
        background-color: #fff;
        border-color: #007bff;
        border-radius: 0;
        padding: 10px 20px !important;
    }
    .page-item:first-child .page-link{
        border-radius: 0 !important;
    }
    .page-item:last-child .page-link{
        border-radius: 0 !important;   
        border-color: #9e6de0;
    }
    .pagination li{
        padding: 3px 5px;
    }
    .disabled .page-link{
        color: #212529 !important;
        opacity: 0.5 !important;
    }

</style>
<?php $__env->startSection('content'); ?>
  <link href="<?php echo e(asset('public/plugins/toaster/toastr.min.css')); ?>" rel="stylesheet" />
<div class="content-wrapper">
          <div class="content">                


                
                <!-- Table Product -->
                <div class="row">
                  <div class="col-12">
                    <div class="card card-default">
                      <div class="card-header">
                        <h2>Device Info</h2>
                      </div>
                      <div class="card-body">
                        <table id="productsTable" class="table table-hover table-product" style="width:100%">
                          <thead>
                            <tr>
                              <th>ID</th>
                              <th>MAC ID</th>
                              <th>Portal</th>
                              <th>Date</th>
                              <th>Time</th>
                              <th>Device Info</th>
                              <th>Status</th>
                              <th>Expiry Date</th>
                              <th>Note</th>
                              <th>Action</th>
                              
                            </tr>
                          </thead>
                          <tbody>
                          <?php $__currentLoopData = $mac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td>
                                <?php echo e($item->id); ?>

                              </td>
                              <td><?php echo e($item->macid); ?></td>
                              <td style="width:12%;">
                              <select class="form-control form-control-sm" id='searchByCurrentPortal' name="portal_name">
                            <option value="null" id="<?php echo e($item->id); ?>" selected>Select Portal</option>
                            <?php $__currentLoopData = $portals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                       <option id="<?php echo e($item->id); ?>" value="<?php echo e($portal->id); ?>"  <?php echo e($portal->id == ($item->portal_name) ? 'selected' : ''); ?>><?php echo e($portal->portal_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                              </td>
                              <td><?php echo e($item->date); ?></td>
                              <td><?php echo e($item->time); ?></td>
                              <td><?php echo e($item->deviceinfo); ?></td>
                              <td>    
    
      <label class="switch switch-success switch-pill form-control-label mr-2">
  <input type="checkbox" class="switch-input form-check-input" id="<?php echo e($item->id); ?>" 
  value="<?php echo e($item->status); ?>"  <?php echo e($item->status == 'true' ? 'checked' : ''); ?>/>
  <span class="switch-label"></span>
  <span class="switch-handle"></span>
</label>
    </td>
    <td><div class="expiry"><?php echo e($item->expiry); ?></div></td>
    <td><div class="notes"><?php echo e($item->note); ?></div></td>
                                                          <td>
                                <div class="dropdown">
                                  <a class="dropdown-toggle icon-burger-mini" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                  </a>

                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                              <a href="<?php echo e(route('item.delete', $item->id)); ?>" class="mb-1 delete-data dropdown-item"> Delete</a>
                                    <!--<a class="dropdown-item" id="devices_note" data-toggle="modal" data-id="<?php echo e($item->id); ?>" data-target="#exampleModalForm" href="javascript:void(0);">Note</a>-->
                                    <a class="dropdown-item" id="expiry_date" data-toggle="modal" data-id="<?php echo e($item->id); ?>" data-target="#exampleModalForming" href="javascript:void(0);">Expiry Date</a>
                                  </div>
                                </div>
                              </td>
                            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                          </tbody>
                        </table>
                            <div class="col-md-12">
                              <?php echo e($mac->links('pagination::bootstrap-4')); ?>

                          </div>
                      </div>
                    </div>
                  </div>
                </div>



              <!-- Stock Modal -->
              <div class="modal fade modal-stock" id="modal-stock" aria-labelledby="modal-stock" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                  <form action="#">
                    <div class="modal-content">
                      <div class="modal-header align-items-center p3 p-md-5">
                        <h2 class="modal-title" id="exampleModalGridTitle">Add Stock</h2>
                        <div>
                          <button type="button" class="btn btn-light btn-pill mr-1 mr-md-2" data-dismiss="modal"> cancel </button>
                          <button type="submit" class="btn btn-primary  btn-pill" data-dismiss="modal"> save </button>
                        </div>

                      </div>
                      <div class="modal-body p3 p-md-5">
                        <div class="row">
                          <div class="col-lg-8">
                            <h3 class="h5 mb-5">Product Information</h3>
                            <div class="form-group mb-5">
                              <label for="new-product">Product Title</label>
                              <input type="text" class="form-control" id="new-product" placeholder="Add Product">
                            </div>
                            <div class="form-row mb-4">
                              <div class="col">
                                <label for="price">Price</label>
                                <div class="input-group">
                                  <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">$</span>
                                  </div>
                                  <input type="text" class="form-control" id="price" placeholder="Price" aria-label="Price"
                                    aria-describedby="basic-addon1">
                                </div>
                              </div>
                              <div class="col">
                                <label for="sale-price">Sale Price</label>
                                <div class="input-group">
                                  <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">$</span>
                                  </div>
                                  <input type="text" class="form-control" id="sale-price" placeholder="Sale Price" aria-label="SalePrice"
                                    aria-describedby="basic-addon1">
                                </div>
                              </div>
                            </div>

                            <div class="product-type mb-3 ">
                              <label class="d-block" for="sale-price">Product Type <i class="mdi mdi-help-circle-outline"></i> </label>
                              <div>

                                <div class="custom-control custom-radio d-inline-block mr-3 mb-3">
                                  <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input" checked="checked">
                                  <label class="custom-control-label" for="customRadio1">Physical Good</label>
                                </div>

                                <div class="custom-control custom-radio d-inline-block mr-3 mb-3">
                                  <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadio2">Digital Good</label>
                                </div>

                                <div class="custom-control custom-radio d-inline-block mr-3 mb-3">
                                  <input type="radio" id="customRadio3" name="customRadio" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadio3">Service</label>
                                </div>

                              </div>
                            </div>

                            <div class="editor">
                              <label class="d-block" for="sale-price">Description <i class="mdi mdi-help-circle-outline"></i></label>
                              <div id="standalone">
                                <div id="toolbar">
                                  <span class="ql-formats">
                                    <select class="ql-font"></select>
                                    <select class="ql-size"></select>
                                  </span>
                                  <span class="ql-formats">
                                    <button class="ql-bold"></button>
                                    <button class="ql-italic"></button>
                                    <button class="ql-underline"></button>
                                  </span>
                                  <span class="ql-formats">
                                    <select class="ql-color"></select>
                                  </span>
                                  <span class="ql-formats">
                                    <button class="ql-blockquote"></button>
                                  </span>
                                  <span class="ql-formats">
                                    <button class="ql-list" value="ordered"></button>
                                    <button class="ql-list" value="bullet"></button>
                                    <button class="ql-indent" value="-1"></button>
                                    <button class="ql-indent" value="+1"></button>
                                  </span>
                                  <span class="ql-formats">
                                    <button class="ql-direction" value="rtl"></button>
                                    <select class="ql-align"></select>
                                  </span>
                                </div>
                              </div>
                              <div id="editor"></div>

                              <div class="custom-control custom-checkbox d-inline-block mt-2">
                                <input type="checkbox" class="custom-control-input" id="customCheck2">
                                <label class="custom-control-label" for="customCheck2">Hide product from published site</label>
                              </div>

                            </div>

                          </div>
                          <div class="col-lg-4">
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="customFile" placeholder="please imgae here">
                              <span class="upload-image">Click here to <span class="text-primary">add product image.</span> </span>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </form>
                </div>
              </div>
</div>


  <div class="modal fade" id="exampleModalForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalFormTitle">Add Note</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/changeNote')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="mac_id" name="mac_id"/>
              <div class="form-group">
                <label for="fname">Devices Info Note</label>
                <textarea type="text" class="form-control" name="note" id="note" placeholder="Please Enter A Note"></textarea>
              </div>
      <div class="modal-save-portal">
        <button type="submit" class="btn btn-primary btn-pill">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
</div>




<div class="modal fade" id="exampleModalForming" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalFormTitle">Expiry Date</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/changeExpiry')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="mac_ids" name="mac_id"/>
              <div class="form-group">
                <label for="fname">Expiry Date</label>
                <label class="expiry">
                <input type="radio" class="form-control" name="expiry" id="expiry_date" value="one_day" placeholder="Please Enter A Note"/><span>One Day</span>
                </label>
                <label class="expiry">
                <input type="radio" class="form-control" name="expiry" id="expiry_date" value="three_month" placeholder="Please Enter A Note"/><span>Three Month</span>
                </label>
                <label class="expiry">
                <input type="radio" class="form-control" name="expiry" id="expiry_date" value="six_month" placeholder="Please Enter A Note"/><span>Six Month</span>
                </label>
                <label class="expiry">
                <input type="radio" class="form-control" name="expiry" id="expiry_date" value="one_year" placeholder="Please Enter A Note"/><span>One Year</span>
                </label>
                <br/>
                <label for="fname">Devices Info Note</label>
                <textarea type="text" class="form-control" name="note" id="notes" placeholder="Please Enter A Note"></textarea>
              </div>
      <div class="modal-save-portal">
        <button type="submit" class="btn btn-primary btn-pill">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
</div>

<style>
  .delete-data
  {
     font-size: 17px;
     color: #2f2f2f;
     margin: 0 !important;
  }
 label.expiry {
	 display: flex;
	 cursor: pointer;
	 font-weight: 500;
	 position: relative;
	 overflow: hidden;
	 margin-bottom: 0.375em;
	/* Accessible outline */
	/* Remove comment to use */
	/* &:focus-within {
		 outline: .125em solid $primary-color;
	}
	 */
}
 label.expiry input {
	 position: absolute;
	 left: -9999px;
}
 label.expiry input:checked + span {
	 background-color: #d6d6e5;
}
 label.expiry input:checked + span:before {
	 box-shadow: inset 0 0 0 0.4375em #00005c;
}
 label.expiry span {
	 display: flex;
	 align-items: center;
	 padding: 0.375em 0.75em 0.375em 0.375em;
	 border-radius: 99em;
	 transition: 0.25s ease;
}
 label.expiry span:hover {
	 background-color: #d6d6e5;
}
 label.expiry span:before {
	 display: flex;
	 flex-shrink: 0;
	 content: "";
	 background-color: #fff;
	 width: 1.5em;
	 height: 1.5em;
	 border-radius: 50%;
	 margin-right: 0.375em;
	 transition: 0.25s ease;
	 box-shadow: inset 0 0 0 0.125em #00005c;
}
.modal-save-portal
{
 padding-bottom:30px;   
}
 
</style>
    <script src="<?php echo e(asset('public/plugins/toaster/toastr.min.js')); ?>"></script>
<script>
    <?php if(Session::has('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>")
    <?php endif; ?>
    <?php if(Session::has('updating')): ?>
    toastr.success("<?php echo e(session('updating')); ?>")
    <?php endif; ?>
    <?php if(Session::has('danger')): ?>
    toastr.error("<?php echo e(session('danger')); ?>")
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN-admin\laravel-maxN-admin\laravel-maxN-admin\resources\views/index.blade.php ENDPATH**/ ?>