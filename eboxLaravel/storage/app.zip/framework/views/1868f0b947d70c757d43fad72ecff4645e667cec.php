

<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
        </ol>
    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Categories</h4>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                              <th>ID</th>
                              <th>MAC ID</th>
                              <th>Date</th>
                              <th>Time</th>
                              <th>Device Info</th>
                              <th>Status</th>
                              <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
		<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($item->id); ?></td>
    <td><?php echo e($item->mac_id); ?></td>
    <td><?php echo e($item->date); ?></td>
    <td><?php echo e($item->time); ?></td>
    <td><?php echo e($item->device_info); ?></td>
    <td>
    <label class="switch">
        <input data-id="<?php echo e($item->id); ?>" class="toggle-class" type="checkbox"
        data-onstyle="success" data-onstyle="danger" data-toggle="toggle" data-on="Active"
        data-off="Inactive" <?php echo e($item->status ? 'checked' : ''); ?>/>  
        <span class="slider"></span>
      </label>
      </td>
    <td>
    <a href="<?php echo e(route('item.delete', $item->id)); ?>" class="mb-1 btn btn-danger">Delete</a>
    </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- #/ container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN\resources\views/index.blade.php ENDPATH**/ ?>