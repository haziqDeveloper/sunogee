
<?php $__env->startSection('content'); ?>
<main class="login-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card login-card">
                    <h3 class="card-header text-center">Sign In</h3>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('login.custom')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                            <label class="form__label" for="email">Email</label>
                                <input type="text" placeholder="Email" id="email" class="form-control form-input" name="email" required
                                    autofocus>
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                            <label class="form__label" for="password">Password</label>
                                <input type="password" placeholder="Password" id="password" class="form-control form-input" name="password" required>
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <div class="checkbox login-box">
                                    <label>
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                            <div class="d-grid mx-auto">
                                <button type="submit" class="btn btn-dark btn-block">Signin</button>
                            </div>
                        </form>
                        <div class="login-text--center">
                       <p>Already have an account? <a href="<?php echo e(url('registration')); ?>">Sign Up</a></p>
                     </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .login-form
        {
            padding-top:100px;
        }
        .card.login-card {
    background: #101010;
    padding: 24px 10px;
}
.card.login-card h3 {
    color: #ffffff;
}
label.form__label {
    color: #fcfcfc;
    display: inline-block;
    font-size: 0.875rem;
    margin-bottom: 0.5em;
    margin-left: 0.5em;
    margin-right: 0.5em;
}
 .form-input{
    background-color: #171717 !important;
    border: 2px solid #191919;
    border-radius: 1em;
    padding: 1em 1.25em;
    -webkit-transition: background-color 0.3s ease-in-out;
    -o-transition: background-color 0.3s ease-in-out;
    transition: background-color 0.3s ease-in-out;
    width: 100%;
}
.login-box label {
    color:#fff;
}
.login-text--center
{
    padding-top:20px;
   text-align:center;   
}
.login-text--center a
{
  color:#fff;
  font-weight:600;
  text-decoration:none;
}
.content_mac
    {
        height:750px !important;
    }
    </style>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-macN\resources\views/auth/login.blade.php ENDPATH**/ ?>