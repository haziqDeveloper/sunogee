<div class="sb-header header-shadow">
		<div class="container">

			<!-- sb header -->
			<div class="sb-header-container">
				
				<!--Logo-->
                <div class="logo" data-mobile-logo="demo/images/logo-dark.png" data-sticky-logo="demo/images/logo-dark.png">
                	<a href="#"><h2>IPLAY TV</h2></a>
				</div>
				
				<!-- Burger menu -->
				<div class="burger-menu">
					<div class="line-menu line-half first-line"></div>
					<div class="line-menu"></div>
					<div class="line-menu line-half last-line"></div>
				</div>

				<!--Navigation menu-->
                <nav class="sb-menu menu-caret submenu-top-border submenu-scale">
                	<ul>
                    	<li class="current-menu"><a href="<?php echo e(url('categories')); ?>">Home</a>
                        </li>
						<li><a href="<?php echo e(url('portal')); ?>">Portals</a></li>
						<li>
						<a class="nav-link" href="<?php echo e(route('signout')); ?>">Sign Out</a></li>
                    </ul>
                </nav>

			</div>

		</div>
	</div>
<?php /**PATH C:\xampp\htdocs\laravel-maxN\resources\views/auth/header.blade.php ENDPATH**/ ?>