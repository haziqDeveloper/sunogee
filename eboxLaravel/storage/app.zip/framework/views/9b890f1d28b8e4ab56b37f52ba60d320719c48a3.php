
<?php $__env->startSection('content'); ?>

<div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('errors')); ?>

    </div>
<?php endif; ?> 
	<div class="row">

    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Message</h4>
                                <div class="basic-form">
                                <form action="<?php echo e(url('/messages')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Email</label>
                                            <div class="col-sm-10">
                                                <input type="email" name="email" value="<?php echo e($message->email); ?>" class="form-control" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Phone Number</label>
                                            <div class="col-sm-10">
                                                <input type="password" name="phone" value="<?php echo e($message->phone); ?>" class="form-control" placeholder="Password">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                        <div class="general-button">
                                    <button type="submit" class="btn mb-1 btn-flat btn-success" id="toastr-success-top-right">Message</button>
                                </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
	</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN\resources\views/message.blade.php ENDPATH**/ ?>