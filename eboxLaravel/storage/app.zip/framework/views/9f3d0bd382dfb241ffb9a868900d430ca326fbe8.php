<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Custom Auth in Laravel</title>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap/bootstrap.css')); ?>">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap/bootstrap.min.css')); ?>">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">

</head>
<body>
<!-- <main class="header-panel">
    <header>
        <h1>pandas</h1>
        <nav>
        <ul>
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register-user')); ?>">Register</a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('signout')); ?>">Logout</a>
                    </li>
                    <?php endif; ?>
                </ul>
        </nav>
    </header>
</main> -->
    <section class="content_mac">
    <?php echo $__env->yieldContent('content'); ?>
</section>
        <!-- <script src="<?php echo e(asset('assets/js/table.js')); ?>"></script> -->
        <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> -->
        <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
  $("#example").DataTable({
    aaSorting: [],
    responsive: true,

    columnDefs: [
      {
        responsivePriority: 1,
        targets: 0
      },
      {
        responsivePriority: 2,
        targets: -1
      }
    ]
  });

  $(".dataTables_filter input")
    .attr("placeholder", "Search here...")
    .css({
      width: "300px",
      display: "inline-block"
    });

  $('[data-toggle="tooltip"]').tooltip();
});
</script>
<script>
	$(document).ready(function() {
		$('.toggle-class').change(function(){
			var status = $(this).prop('checked') == true ? 1 : 0;
			var item_id = $(this).data('id');
			$.ajax({
				type:"GET",
				dataType:"json",
				url:'/changeStatus',
				data: {'status':status, 'item_id': item_id},
				success: function(data){
					console.log(data.success)
				}	
			}) 
		});
	});
</script>

<style>
   .content_mac
    {
        background:#444442;
        background-size:cover;
        background-repeat:no-repeat;
        position:relative;
        height:750px;
    }
    .table>thead {
    vertical-align: bottom;
    background: #2D2D2D;
    color:#fff;
}
    .mb-5 {
    margin-bottom: 0!important;
}
div#example_wrapper {
    padding-top: 50px;
}
div#example_filter label {
    color: #fff;
    font-size: 20px;
    margin-right: 20px;
}
.header-panel header {
	 background: white;
	 box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}
.header-panel h1 {
	 font: normal 4em 'Playfair Display SC', serif;
	 text-align: center;
}
.header-panel nav {
	 max-width: 800px;
	 margin: auto;
	 display: flex;
	 flex-wrap: wrap;
}
.header-panel nav a {
	 flex-grow: 1;
	 text-align: center;
	 padding: 1em;
	 position: relative;
}
.header-panel nav a::after {
	 content: '';
	 position: absolute;
	 bottom: 0;
	 left: 0;
	 right: 0;
	 height: 2px;
	 transform: scaleX(0);
	 background: #333;
	 transition: 0.7s transform cubic-bezier(0.06, 0.9, 0.28, 1);
}
.header-panel nav a:hover::after {
	 transform: scaleX(1);
}
main.header-panel ul li {
    display: inline-block;
}
main.header-panel ul li a{
    color:#000;
}
ul,ol{
    margin-bottom:0;
    padding-left:0;
}
body
{
    overflow-x:hidden;
}
    </style>
</body>
</html><?php /**PATH /home/paneliplaytv/public_html/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>