
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
          <div class="content"><!-- For Components documentaion -->
          
<div class="card card-default">
      <div class="card-header">
        <h2>Portal</h2>
        <button type="button" class="btn btn-info btn-pill" data-toggle="modal" data-target="#exampleModalForm">
            Add Portal
        </button>

        <div class="modal fade" id="exampleModalForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalFormTitle">Add Portal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/portals')); ?>">
            <?php echo csrf_field(); ?>
        <div class="form-group">
                <label for="fname">Portal Name</label>
                <input type="text" class="form-control" name="portal_name" placeholder="Portal Name">
              </div>
              <div class="form-group">
                <label for="fname">Portal Address</label>
                <input type="text" class="form-control" name="portal_address" placeholder="Portal Address">
              </div>
      <div class="modal-save-portal">
        <button type="submit" class="btn btn-primary btn-pill">Save Changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
</div>
      </div>
      <div class="card-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Portal Name</th>
              <th scope="col">Portal Address</th>
              <th class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $portal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td scope="row"><?php echo e($port->id); ?></td>
              <td><?php echo e($port->portal_name); ?></td>
              <td><?php echo e($port->portal_address); ?></td>
              <th class="text-center">
                <button value="<?php echo e($port->id); ?>" class="editbtn">
                  <i class="mdi mdi-open-in-new"></i>
                </button>
                <a href="<?php echo e(route('port.delete', $port->id)); ?>">
                  <i class="mdi mdi-close text-danger"></i>
                </a>
              </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
</div>
</div>


<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalFormTitle">Update Portal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/portal-update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>  
            <input type="hidden" id="portal_id" name="portal_id"/>
        <div class="form-group">
                <label for="fname">Portal Name</label>
                <input type="text" class="form-control" name="portal_name" id="portal_name" placeholder="Portal Name">
              </div>
              <div class="form-group">
                <label for="fname">Portal Address</label>
                <input type="text" class="form-control" name="portal_address" id="portal_address" placeholder="Portal Address">
              </div>
      <div class="modal-save-portal">
        <button type="submit" class="btn btn-primary btn-pill">Update Changes</button>
      </div>
      </form>
    </div>
  </div>
</div>




<style>
    .modal-save-portal
    {
       margin-top:30px;
       margin-bottom:20px;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('.editbtn').on('click',function(){
      var portal_id = $(this).val();
      console.log("hi",portal_id);
      $('#editModal').modal('show');
      $.ajax({
        type: "GET",
        url: "/portal-edit/"+portal_id,
        success: function (response)
        {
          console.log(response.portal);
          $('#portal_name').val(response.portal.portal_name);
          $('#portal_address').val(response.portal.portal_address);
          $('#portal_id').val(response.portal.id);
        }
      })
  });
});
</script>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN-admin\laravel-maxN-admin\laravel-maxN-admin\resources\views/portal.blade.php ENDPATH**/ ?>