
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('auth.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="port_back">
<div class="container">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('errors')); ?>

    </div>
<?php endif; ?> 
    <form action="<?php echo e(url('/portals')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

	<div class="row">
			<div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>UserName</label> 
					<input type="text" name="name" class="form-control"/>
				</div>
			</div>
			</div>

            <div class="row">
            <div class="col-md-6 col-sm-12">
				<div class="form-group port-desing">
                <label>Email</label> 
					<input type="text" name="email" class="form-control"/>
				</div>
			</div>
			<div class="port_update">
				<input type="submit" class="btn btn-primary btn-lg" value="Submit The Data"/>
			</div>
	</div>
</form>
</div>
<style>
    .port_update input {
    padding: 12px 20px;
    width: 16%;
    font-weight: 600;
}
.form-group.port-desing input {
    border-radius: 0;
    background: #fff;
    height: 50px;
    border: 1px solid #ffffff;
    margin-bottom: 30px;
    color: #444;
}
.form-group.port-desing label {
    color: #000000;
    font-size: 18px;
    margin-bottom: 10px;
    font-weight: 600;
}
.panel_portol h1 {
    font-family: 'Poppins', sans-serif, 'arial';
    font-weight: 600;
    font-size: 40px;
    color: #000;
    padding-top:50px;
}

h4 {
    font-family: 'Roboto', sans-serif, 'arial';
    font-weight: 400;
    font-size: 20px;
    color: #9b9b9b;
    line-height: 1.5;
}

/* ///// inputs /////*/

input:focus ~ label, textarea:focus ~ label, input:valid ~ label, textarea:valid ~ label {
    font-size: 0.75em;
    color: #999;
    top: -5px;
    -webkit-transition: all 0.225s ease;
    transition: all 0.225s ease;
}

.styled-input {
    float: left;
    width: 293px;
    margin: 1rem 0;
    position: relative;
    border-radius: 4px;
}

@media  only screen and (max-width: 768px){
    .styled-input {
        width:100%;
    }
}

.styled-input label {
    color: #999;
    padding: 1.3rem 30px 1rem 30px;
    position: absolute;
    top: 10px;
    left: 0;
    -webkit-transition: all 0.25s ease;
    transition: all 0.25s ease;
    pointer-events: none;
}

.styled-input.wide { 
    width: 650px;
    max-width: 100%;
}

input,
textarea {
    padding: 30px;
    border: 0;
    width: 100%;
    font-size: 1rem;
    background-color: #2d2d2d;
    color: white;
    border-radius: 4px;
}

input:focus,
textarea:focus { outline: 0; }

input:focus ~ span,
textarea:focus ~ span {
    width: 100%;
    -webkit-transition: all 0.075s ease;
    transition: all 0.075s ease;
}

textarea {
    width: 100%;
    min-height: 15em;
}
section.port_back {
    padding-top: 60px;
}
.logo a h2 {
    color: #000000;
    text-decoration: none;
    border-bottom: 0;
    font-weight: 900;
}
a {
    text-decoration: none;
}
.input-container {
    width: 650px;
    max-width: 100%;
    margin: 20px auto 25px auto;
}

.submit-btn {
    float: right;
    padding: 7px 35px;
    border-radius: 60px;
    display: inline-block;
    background-color: #4b8cfb;
    color: white;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.06),
              0 2px 10px 0 rgba(0,0,0,0.07);
    -webkit-transition: all 300ms ease;
    transition: all 300ms ease;
}

.submit-btn:hover {
    transform: translateY(1px);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,0.10),
              0 1px 1px 0 rgba(0,0,0,0.09);
}

@media (max-width: 768px) {
    .submit-btn {
        width:100%;
        float: none;
        text-align:center;
    }
}

input[type=checkbox] + label {
  color: #ccc;
  font-style: italic;
} 

input[type=checkbox]:checked + label {
  color: #f00;
  font-style: normal;
}
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-maxN\resources\views/view.blade.php ENDPATH**/ ?>