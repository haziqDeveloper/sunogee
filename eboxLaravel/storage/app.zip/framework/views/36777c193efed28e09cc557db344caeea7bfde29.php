

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="row">
<div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Ibox Domain Url</h5>
                    </div>
                    <div class="card-body">
                      <form method="POST" action="<?php echo e(url('/ibox-domain-urls')); ?>">
                      <?php echo e(csrf_field()); ?>

                      <?php $__currentLoopData = $subAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">Domain Url</label>
                          <input type="url" class="form-control" name="url" value="<?php echo e($admin->url); ?>" id="basic-default-fullname" placeholder="https://Ibox.com"/>
                        </div>
                        <div class="general-button">
                          <button type="submit" id="submit" class="btn mb-1 btn-flat btn-success">Update Url</button>
                        </div>
                      </form>

                    </div>
                  </div>
                </div>
</div>
</div>
<style>
    .general-button
    {
        margin-top:30px;
        margin-bottom:20px;
    }
</style>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/andreddu/public_html/resources/views/Dashboard/Admin/IboxDomainUrl.blade.php ENDPATH**/ ?>