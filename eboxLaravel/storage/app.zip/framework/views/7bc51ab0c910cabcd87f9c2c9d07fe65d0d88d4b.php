

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="row">
<div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Ibo Contact Detail</h5>
                    </div>
                    <div class="card-body">
                      <form method="POST" action="<?php echo e(url('/ibo-contact-details')); ?>">
                      <?php echo e(csrf_field()); ?>

                      <?php $__currentLoopData = $ContactDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">Email</label>
                          <input type="email" class="form-control" name="email" value="<?php echo e($cont->email); ?>" id="basic-default-fullname" placeholder="admin@gmail.com"/>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">Phone</label>
                          <input type="text" class="form-control" name="phone" value="<?php echo e($cont->phone); ?>" id="basic-default-fullname" placeholder="111-000-111"/>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">Info</label>
                          <textarea type="text" class="form-control" name="info" 
                           id="basic-default-fullname" placeholder="Your Info"><?php echo e($cont->info); ?></textarea>
                        </div>
                        
                        <div class="general-button">
                          <button type="submit" id="submit" class="btn mb-1 btn-flat btn-primary">Contact Update</button>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </form>

                    </div>
                  </div>
                </div>
</div>
</div>
<style>
    .general-button
    {
        margin-top:30px;
        margin-bottom:20px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/andreddu/public_html/resources/views/Dashboard/Admin/IboContactDetail.blade.php ENDPATH**/ ?>