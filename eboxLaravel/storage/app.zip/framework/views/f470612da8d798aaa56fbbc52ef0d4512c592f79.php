
<?php $__env->startSection('content'); ?>
<main class="signup-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card signup-card">
                    <h3 class="card-header text-center">Sign Up User</h3>
                    <div class="card-body">
                        <form action="<?php echo e(route('register.custom')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                               <label class="form__label" for="name">UserName</label>
                                <input type="text" placeholder="Name" id="name" class="form-control form-input" name="name"
                                    required autofocus>
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                            <label class="form__label" for="email">Email</label>
                                <input type="text" placeholder="Email" id="email_address" class="form-control form-input"
                                    name="email" required autofocus>
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                            <label class="form__label" for="password">Password</label>
                                <input type="password" placeholder="Password" id="password" class="form-control form-input"
                                    name="password" required>
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <div class="checkbox signup-box">
                                    <label><input type="checkbox" name="remember"> Remember Me</label>
                                </div>
                            </div>
                            <div class="d-grid mx-auto">
                                <button type="submit" class="btn btn-dark btn-block">Sign up</button>
                            </div>
                        </form>
                        <div class="signup-text--center">
                       <p>Already have an account? <a href="<?php echo e(url('login')); ?>">Log in</a></p>
                     </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .signup-form
        {
            padding-top:100px;
        }
        .card.signup-card {
    background: #101010;
    padding: 24px 10px;
}
.card.signup-card h3 {
    color: #ffffff;
}
label.form__label {
    color: #fcfcfc;
    display: inline-block;
    font-size: 0.875rem;
    margin-bottom: 0.5em;
    margin-left: 0.5em;
    margin-right: 0.5em;
}
 .form-input{
    background-color: #171717;
    border: 2px solid #191919;
    border-radius: 1em;
    padding: 1em 1.25em;
    -webkit-transition: background-color 0.3s ease-in-out;
    -o-transition: background-color 0.3s ease-in-out;
    transition: background-color 0.3s ease-in-out;
    width: 100%;
}
.signup-box label {
    color:#fff;
}
.signup-text--center
{
    padding-top:20px;
   text-align:center;   
}
.signup-text--center a
{
  color:#fff;
  font-weight:600;
  text-decoration:none;
}
    </style>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-macN\resources\views/auth/registration.blade.php ENDPATH**/ ?>