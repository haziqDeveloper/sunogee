

<?php $__env->startSection('content'); ?>

            <!-- row -->
            <div class="container-fluid">
                <div class="row">
<div class="col-lg-12">
                        <div class="card card-android">
                            <div class="card-body">
                                <h4 class="card-title">APK Upload File</h4>
                                <br/>
                                <div class="basic-form">
           <form method="post" action="<?php echo e(url('/upload-files')); ?>"  enctype="multipart/form-data">
                                  <?php echo e(csrf_field()); ?>

                                    <?php $__currentLoopData = $upload; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                     <br/>
                                        <fieldset class="form-group">
                                            <div class="row">
                                                <div class="col-sm-10">
                                                    <div class="form-group">
                                                                                <label class="col-form-label col-sm-2 pt-0">APK File</label><br/>
                                <input type="file" name="file" value="<?php echo e(asset('storage/app/'.$vers->file)); ?>" class="form-control-file">
                                                    <img src=<?php echo e(asset('storage/app/'.$vers->file)); ?> width="200" height="200" alt=""/>
                                                    <a href="<?php echo e(asset('storage/app/'.$vers->file)); ?>" download>Download File</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <br/>
                                        <div class="form-group row">
                                            <div class="col-sm-10">
                                            <div class="general-button">
                                    <button type="submit" class="btn mb-1 btn-flat btn-success">Update File</button>
                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    <style>
    .general-button
    {
        margin-top:30px;
        margin-bottom:20px;
    }
    .card.card-android {
    margin-top: 20px;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/andreddu/public_html/resources/views/Dashboard/Admin/UploadFile.blade.php ENDPATH**/ ?>