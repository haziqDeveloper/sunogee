<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MediaIboVersion extends Model
{
    use HasFactory;
    protected $table = "mediaiboversion"; 
}
