<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IboVersion extends Model
{
    use HasFactory;
    protected $table = "ibo_versions"; 
}
