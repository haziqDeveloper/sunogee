<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SubAdmin;
use App\Models\Contact;
use Illuminate\Support\Facades\Auth;

class SubAdminController extends Controller
{   
    public function apiSubAdmin()
   {
     $subAdmin = SubAdmin::all();
     return response()->json($subAdmin);
   }

    function getSubAdmin()
    {

        $subAdmin = SubAdmin::all();
        if(Auth::check()) {
            return view('dashboard.admin.AddSubAdmin', compact('subAdmin'));    
     }

     return redirect::to("/")->withSuccess('Oopps! You do not have access');
        
    }

    function getContact()
    {

        $contact = Contact::all();
        if(Auth::check()) {
            return view('dashboard.admin.AddContactDetail', compact('contact'));    
     }

     return redirect::to("/")->withSuccess('Oopps! You do not have access');
        
    }

    function storeSubAdmin(Request $request)
    {   
        $subAdmin = SubAdmin::where($request->id)->update([
            'url'=>$request->input('url'),
        ]);
        return redirect('/add-domain-url');       
    }

    function storeContact(Request $request)
    {   
        $contact = Contact::where($request->id)->update([
            'email'=>$request->input('email'),
            'phone'=>$request->input('phone'),
            'message'=>$request->input('message'),
        ]);
        return redirect('/contact-detail');       
    }
}
